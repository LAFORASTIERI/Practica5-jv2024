package practica5jv2024;
import java.util.Scanner;

public class Main {

	
	public static void main(String[] args) {
		
        int tamanoEquipo = 0;

		Scanner scanner = new Scanner(System.in);

        System.out.println("Ingrese el nombre del equipo:");
        String nombreEquipo = scanner.nextLine();

        System.out.println("Ingrese la universidad:");
        String universidad = scanner.nextLine();

        System.out.println("Ingrese el lenguaje de programación:");
        String lenguajeProgramacion = scanner.nextLine();
        
        
        EquipoProgramacion equipo = new EquipoProgramacion(nombreEquipo, universidad, lenguajeProgramacion,tamanoEquipo);
     
        
        while (!equipo.equipoCompleto()) {
             try {
            	 
            	Programador programador = new Programador(); 
            	
              	System.out.println("Ingrese el nombre del programador:");
                String nombre = scanner.nextLine();
                programador.setNombre(nombre);
       
                System.out.println("Ingrese el apellido del programador:");
                String apellido = scanner.nextLine();
                programador.setApellido(apellido);
                
                equipo.cargarProgramador(programador);
                
            } catch (IllegalArgumentException | IllegalStateException e) {
                System.out.println(e.getMessage());
            }
        }
        System.out.println("\n----------------------------------\n");
        System.out.println("Equipo completo");
        System.out.println("\n----------------------------------\n");
        System.out.println(equipo.toString());
        
        scanner.close();

	}
			
}
		