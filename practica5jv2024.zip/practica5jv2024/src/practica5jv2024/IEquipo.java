package practica5jv2024;

public interface IEquipo {

	int MINPROGRAMADORES = 2;
	int MAXPROGRAMADORES = 3;
	
	//Método
	
	boolean equipoCompleto();
	
}
