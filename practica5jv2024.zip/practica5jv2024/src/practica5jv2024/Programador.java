package practica5jv2024;

public class Programador {
	
	private String nombre;
	private String apellido;
	
	//Constructores
	
	public Programador (String nombre, String apellido) {
		this.nombre= nombre;
		this.apellido=apellido;
	}
	
	public Programador() {
		
	}
	
	//Getters y Setters

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		validarNombre(nombre);
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		validarApellido(apellido);
		this.apellido = apellido;
	}
	

	//Métodos
	
	public void validarNombre (String nombre) {
		if (!nombre.matches("[a-zA-Z]+")) {
			throw new IllegalArgumentException("El nombre ingresado sólo debe contener letras.");
		}
	}
		
	public void validarApellido (String apellido) {
		if (!apellido.matches("[a-zA-Z]+")) {
			throw new IllegalArgumentException("El apellido ingresado sólo debe contener letras.");
		}
		
	}

	
	//To String
		
	@Override
	public String toString() {
		return "\nProgramador:\n" +
			"\tNombre: " + nombre + "\n"+ 
			"\tApellido: " + apellido;
		}
					
	

}//Fin clase
