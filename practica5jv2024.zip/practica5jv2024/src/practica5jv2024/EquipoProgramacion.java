package practica5jv2024;

import java.util.ArrayList;
import java.util.List;

public class EquipoProgramacion extends Equipo implements IEquipo {

	private List <Programador> programadores;
	
	//Constructores
	
	public EquipoProgramacion (String nombreEquipo, String universidad, String lenguaje, int tamanoEquipo ) {
		super (nombreEquipo, universidad, lenguaje, tamanoEquipo);
		this.programadores= new ArrayList<>();
	}
	
	public EquipoProgramacion () {
		
	}
	
	@Override // ¿Equipo completo?
	public boolean equipoCompleto() {
		return programadores.size() == MAXPROGRAMADORES;
	}
	
	
	//Método
	public void cargarProgramador (Programador programador) {
		if (programadores.size()>=MAXPROGRAMADORES) {
			throw new IllegalStateException ("No es posible añadir más programadores. El equipo está completo");
		} else {
			programadores.add(programador);
			setTamanoEquipo(programadores.size());
		}
	}
	
		
	//To STring
	
	@Override
	public String toString() {
		return super.toString() + "Programadores: \n" + programadores ;

	}

} //fin clase


